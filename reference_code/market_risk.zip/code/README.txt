#Read me:

Submission includes below files:
1. RiskCalculationEngine.py - Main implementation with all risk impl
2. TechnicalIndicatorsStrategy.py - Technical Indicator strategy
3. TestProject.py -  Test project which does experiments
4. indicators.py - This implements Part 1: Technical indicators of the project. It has calculation for computing 5 technical indicators and plotting the graphs as per project requirement.
5. Charts - contains charts produced
6. util.py - utility methods