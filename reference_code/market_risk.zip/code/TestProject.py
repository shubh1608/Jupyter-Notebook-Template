""""""
""" Test Project, has all experiment
Student Name: Ravindra Singh  		  	   		     		  		  		    	 		 		   		 		  
	  	   		     		  		  		    	 		 		   		 		  
"""

import numpy as np
import pandas as pd
from pandas_datareader import data as pdr
import Indicators as indicators

import RiskCalculationEngine as rce

if __name__ == "__main__":

    # Our portfolio comprises of AAPLE and IBM stocks. This is configurable and can be changed here as needed
    tickers = ['AAPL','IBM']
    start_date = '2008-01-01'
    end_date = '2018-12-31'
    # initial investment start value
    start_val = 1000000
    alpha_confidence_levels = [0.10, 0.05, 0.01]
    start_vals = np.array([100000, 100000])

    df_closing_prices = rce.get_data_from_yahoo_finance(start_date, end_date, tickers)
    portfolio_value = df_closing_prices[tickers[0]].sum() + df_closing_prices[tickers[1]].sum()
    # calculate periodic returns
    periodic_return = df_closing_prices.pct_change()
    # create var-covar matrix
    var_covar_matrix = periodic_return.cov()

    # Experiment-1.Variance-Covariance (Parametric Approach) method to calculate RISK - VAR, CVAR(aka Expected Shortfall)
    print('=========Experiment-1, CVaR calculation using Variance-Covariance (Parametric Approach)===')
    rce.calculate_risk_using_variance_covariance(df_closing_prices, start_val, tickers)

    print('=========Experiment-2, Historical Approach to calculate RISK - VAR, CVAR(aka Expected Shortfall)===')
    # Experiment-2.Historical Approach to calculate RISK - VAR, CVAR(aka Expected Shortfall)
    #For the historical approach, we assume that the future changes in the exchange rate will follow the exact distribution as the past changes in the exchange rate

    for ticker in tickers:
        df_closing_prices[ticker].hist(bins=40, density=True, histtype='stepfilled', alpha=0.3)
    rce.calculate_risk_using_hist_sim(df_closing_prices, start_vals, alpha_confidence_levels)

    print('=========Experiment-3, Monte-Carlo Simulation Approach to calculate RISK - VAR, CVAR(aka Expected Shortfall)===')
    # Experiment-3.Monte-Carlo Simulation Approach to calculate RISK - VAR, CVAR(aka Expected Shortfall)
    # The simulation approach (aka Monte Carlo simulation approach) draws random samples from a given distribution to estimate future rates and earnings
    num_simulations = 4000
    num_days = 30
    df_simulation = pd.DataFrame()
    starting_point = start_vals * df_closing_prices.iloc[-1]

    rce.calculate_risk_using_monte_carlo_simulation(df_simulation, num_days, num_simulations, portfolio_value, starting_point, var_covar_matrix, alpha_confidence_levels)

    print('=========Experiment-4, Use Technical Indicators and Manual Strategy approach to calculate RISK - VAR, CVAR(aka Expected Shortfall)===')
    # Experiment -4, Use Technical Indicators and Manual Strategy
    indicators.test_code()

    print('=========Experiment-5, Use RNN, LSTM to predict stock price and then apply VAR, CVAR on that===')
    # Experiment-5, Use RNN, LSTM to predict stock price and then apply VAR, CVAR on that
    df_prices = pdr.get_data_yahoo(ticker, start=start_date, end=end_date)
    rce.calculate_risk_using_lstm(df_prices, df_closing_prices)

    print('=========Experiment-6, Reinforcement learning to predict stock price and then apply VAR, CVAR on that===')
    # Experiment-6, Use Reinforcement learning to predict stock price and then apply VAR, CVAR on that