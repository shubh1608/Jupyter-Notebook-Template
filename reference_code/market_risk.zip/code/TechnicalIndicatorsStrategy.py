""""""
"""INDICATOR EVALUATION.
Student Name: Ravindra Singh  		  	   		     		  		  		    	 		 		   		 		  
	  	   		     		  		  		    	 		 		   		 		  
"""

import datetime as dt

import pandas as pd

import TechnicalIndicatorsStrategy as ms
import Indicators as indicators
import matplotlib.pyplot as plt
from util import get_data


def testPolicy(symbol='JPM', sd=dt.datetime(2010, 1, 1), ed=dt.datetime(2011, 12, 31), sv=100000):
    dates = pd.date_range(sd, ed)
    syms = [symbol]
    #syms = symbols.tolist()
    #prices_all = get_data(symbols, dates, True, 'Adj Close')
    prices_all = get_data(syms, dates)
    prices_all = prices_all[syms]
    orders = []
    lookback = 20

    # . Indicator source
    # sources https://www.visualcapitalist.com/12-types-technical-indicators-stocks/
    # https://www.ig.com/us/trading-strategies/10-trading-indicators-every-trader-should-know-190604

    standard_deviation, df_prices_for_sd = indicators.compute_standard_deviation(prices_all, lookback)

    sma_normalized, df_prices_for_sma_calc = indicators.compute_sma(prices_all, lookback)

    # 1. compute BB
    top_band, bottom_band, bollinger_band, df_bb = indicators.compute_bollinger_band(prices_all, lookback)

    # 2. Trend indicators - compute Moving Average Convergence Divergence (MACD)
    macd, df_macd = indicators.compute_macd(prices_all)

    # 3.  - Commodity Channel Index (CCI)
    commodity_channel_index, df_commodity_channel_index = indicators.compute_commodity_channel_index(prices_all, lookback)

    # As per assignment instructions  create a single logical expression that yields a -1, 0, or 1, corresponding to a “short,” “out” or “long” position
    # -1 : short - SELL
    # 0  : out   - DONE
    # 1 : long   - BUY
    stock_yield = 0

    # Our strategy here to make optimum policy for JPM as below:
    current_holding = 0
    previous_order_temp = 0
    previous_order =0
    for index, row in prices_all.iterrows():

        # https://school.stockcharts.com/doku.php?id=technical_indicators:bollinger_band_perce
        # uptrend begins when %B is above .80. Since Stock price going up, lets SELL.
        # Downtrends are identified when %B is below .20. Since Stock price going down, lets BUY
        if (df_bb.loc[index, 'BB']) > 0.80:
            stock_yield = stock_yield + (-1)  # -1 : short - SELL
        elif (df_bb.loc[index, 'BB']) < 0.20:
            stock_yield = stock_yield + 1  # 1 : long   - BUY
        else:
            stock_yield = stock_yield + 0

        # https://school.stockcharts.com/doku.php?id=technical_indicators:moving_average_convergence_divergence_macd
        # Positive values increase as the shorter EMA diverges further from the longer EMA. This means upside momentum is increasing
        # Negative MACD values indicate that the 12-day EMA is below the 26-day EMA. Negative values increase as the shorter EMA diverges further below the longer EMA.
        # This means downside momentum is increasing.
        if df_macd.loc[index, 'MACD'] > df_macd.loc[index, 'MACD_SIGNAL']:
            stock_yield = stock_yield + (-1)  # -1 : short - SELL
        elif (df_macd.loc[index, 'MACD']) < df_macd.loc[index, 'MACD_SIGNAL']:
            stock_yield = stock_yield + 1  # 1 : long   - BUY
        else:
            stock_yield = stock_yield + 0

        # https://school.stockcharts.com/doku.php?id=technical_indicators:commodity_channel_index_cci
        # Commodity Channel Index (CCI) can be used as either a coincident or leading indicator
        # Coincident indicator, surges above +100 reflect strong price action that can signal the start of an uptrend
        # Plunges below -100 reflect weak price action that can signal the start of a downtrend.
        if (df_commodity_channel_index.loc[index, 'CCI']) > 100:
            stock_yield = stock_yield + (-1)  # -1 : short - SELL
        elif (df_commodity_channel_index.loc[index, 'CCI']) < -100:
            stock_yield = stock_yield + 1  # 1 : long   - BUY
        else:
            stock_yield = stock_yield + 0

        if stock_yield >= 1:
            orders.append([index, 1000 - previous_order])
            previous_order_temp = 1000 - previous_order
        elif stock_yield <= -1:
            orders.append([index, -1000 - previous_order])
            previous_order_temp = -1000 - previous_order
        else:
            orders.append([index, - previous_order])
            previous_order_temp = -1000 - previous_order

        previous_order = previous_order + previous_order_temp

        # if stock_yield >= 1 and current_holding == 1000:
        #     orders.append([index, -2000 ])
        #     current_holding = -1000
        # elif stock_yield >= 1 and current_holding == 0:
        #     orders.append([index, 1000])
        #     current_holding = 1000
        # elif stock_yield <= -1 and current_holding == -1000:
        #     orders.append([index, 2000])
        #     current_holding = 1000
        # elif stock_yield <= -1 and current_holding == 1000:
        #     orders.append([index, -2000])
        #     current_holding = -1000
        # else:
        #     if len(orders) == 0:
        #         orders.append([index,0])
        #     else:
        #         orders.append([index, orders[-1][1]])

    df_trades = pd.DataFrame(orders, columns=['Date', 'Shares'])
    df_trades = df_trades.set_index('Date')
    return df_trades


def test_code():
    """
    Helper function to test code
    """
    # this is a helper function you can use to test your code
    # note that during autograding his function will not be called.
    # Define input parameters

    sd = dt.datetime(2008, 1, 1)
    ed = dt.datetime(2009, 12, 31)
    start_val = 100000

    # Process orders
    symbols = ['JPM']
    dates = pd.date_range(sd, ed)
    #prices_all = get_data(symbols, dates, True, 'Adj Close')
    prices_all = get_data(symbols, dates)
    prices_all = prices_all[symbols]

    df_trades = ms.testPolicy(symbols, sd, ed, sv=100000)

    # Optimized portfolio
    df_final_portfolio_value = msc.compute_portvals(df_trades, start_val=start_val)
    df_final_portfolio_value_normalized = df_final_portfolio_value.divide(df_final_portfolio_value.iloc[0, :])
    if isinstance(df_final_portfolio_value, pd.DataFrame):
        df_final_portfolio_value = df_final_portfolio_value[
            df_final_portfolio_value.columns[0]]  # just get the first column
    else:
        "warning, code did not return a DataFrame"

    daily_returns = msc.calculate_daily_return(df_final_portfolio_value)
    # cumulative return
    cumulative_return = df_final_portfolio_value[-1] / df_final_portfolio_value[0] - 1
    # average daily return
    average_daily_return = daily_returns.mean(axis=0)
    # standard daily return
    std_daily_return = daily_returns.std()

    print('cumulative_return, average_daily_return, std_daily_return',
          [cumulative_return, average_daily_return, std_daily_return])

    df_trades = prices_all
    df_trades['Shares'] = 0.0
    df_trades['Shares'].iloc[0] = 1000
    df_benchmark_port_val = msc.compute_portvals(df_trades, start_val=start_val)
    #df_benchmark_port_val.fillna(method='ffill', inplace=True)
   # df_benchmark_port_val.fillna(method='bfill', inplace=True)
    df_benchmark_port_val_normalized = df_benchmark_port_val.divide(df_benchmark_port_val.iloc[0, :])
    if isinstance(df_benchmark_port_val, pd.DataFrame):
        df_benchmark_port_val = df_benchmark_port_val[df_benchmark_port_val.columns[0]]  # just get the first column
    else:
        "warning, code did not return a DataFrame"

    daily_returns_benchmark = msc.calculate_daily_return(df_benchmark_port_val)
    # cumulative return
    cumulative_return_benchmark = df_benchmark_port_val[-1] / df_benchmark_port_val[0] - 1
    # average daily return
    average_daily_return_benchmark = daily_returns_benchmark.mean(axis=0)
    # standard daily return
    std_daily_return_benchmark = daily_returns_benchmark.std()

    print('cumulative_return_benchmark, average_daily_return_benchmark, std_daily_return_benchmark',
          [cumulative_return_benchmark, average_daily_return_benchmark, std_daily_return_benchmark])

    plt.clf()
    plt.close()
    df_final_portfolio_value_normalized.columns = ['Manual Strategy']
    ax = df_final_portfolio_value_normalized.plot(figsize=(10, 4), label='Manual Strategy', color='red')
    df_benchmark_port_val_normalized.columns = ['Benchmark Strategy']
    df_benchmark_port_val_normalized.plot(figsize=(10, 4), ax=ax, label='Benchmark Strategy', color='green')
    plt.legend()
    #plt.figure(figsize=(14, 8))
    plt.title('Manual Strategy vs Benchmark Learner')
    #plt.axis('tight')
    plt.ylabel('PV(normalized)')
    plt.ylim([0.1, 8])
    plt.grid()
    plt.savefig('Manual Strategy vs Benchmark Learner.png')


if __name__ == "__main__":
    test_code()
