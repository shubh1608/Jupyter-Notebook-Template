""""""
"""INDICATOR EVALUATION.
Student Name: Ravindra Singh  		  	   		     		  		  		    	 		 		   		 		  
	  	   		     		  		  		    	 		 		   		 		  
"""
import datetime as dt

import matplotlib.pyplot as plt
import pandas as pd

from util import get_data


def compute_standard_deviation(prices_all, lookback):
    """
    function to compute the momentum
    """
    # Indicator -1
    #prices_all = prices_all.divide(prices_all.iloc[0])
    df_prices_for_sd = prices_all.copy()
    #df_prices_for_sd['Prices(normalized)'] = df_prices_for_sd
    standard_deviation = prices_all.rolling(lookback).std()
    df_prices_for_sd['STD'] = standard_deviation
    return standard_deviation, df_prices_for_sd


def compute_sma(prices_all, lookback):
    """
    function to compute the sma aka simple moving average
    """
    # Indicator -2
    # Calculate as per lecture - 7. A few indicators: Simple moving average by Prof. Balch
    #prices_all = prices_all.divide(prices_all.iloc[0])
    df_prices_for_sma_calc = prices_all.copy()

    #df_prices_for_sma_calc['NORM_PRICES'] = prices_all
    sma_normalized = prices_all.rolling(lookback).mean()
    df_prices_for_sma_calc['SMA_NORM'] = sma_normalized
    df_prices_for_sma_calc['PRICES_BY_SMA'] = prices_all.divide(sma_normalized)
    return sma_normalized, df_prices_for_sma_calc


def compute_bollinger_band(prices_all, lookback):
    """
    function to compute the bollinger band
    """
    # Indicator -3

    # calculate as per lecture 8. A few indicators: Bollinger Bands by Prof. Balch
    # normalize
    #prices_all = prices_all.divide(prices_all.iloc[0])
    df_bb = prices_all.copy()

    simple_moving_average = prices_all.rolling(lookback).mean()
    df_bb['SMA'] = simple_moving_average
    standard_deviation = prices_all.rolling(lookback).std()
    df_bb['STD'] = standard_deviation
    top_band = simple_moving_average + (2 * standard_deviation)
    df_bb['TOP_BAND'] = top_band
    bottom_band = simple_moving_average - (2 * standard_deviation)
    df_bb['BOTTOM_BAND'] = bottom_band
    #bb = (prices_all - simple_moving_average) / (2 * standard_deviation)
    bb = (prices_all - simple_moving_average) / (standard_deviation)
    df_bb['BB'] = bb
    return top_band, bottom_band, bb, df_bb


def compute_macd(prices_all):
    """
    function to compute the momentum
    """
    # Indicator -4
    # Formula to calculate MACD
    # Source: https://www.investopedia.com/terms/m/macd.asp
    # MACD = 12-Period EMA − 26-Period EMA
    prices_all = prices_all.divide(prices_all.iloc[0])
    df_macd = prices_all.copy()
    df_macd['Prices'] = df_macd
    # An exponential moving average (EMA), also known as an exponentially weighted moving average (EWMA),[5]
    # is a first-order infinite impulse response filter that applies weighting factors which decrease exponentially.
    ewma = pd.Series.ewm

    ema_12_period = ewma(prices_all, span=12).mean()
    df_macd['EMA_12'] = ema_12_period
    ema_26_period = ewma(prices_all, span=26).mean()
    df_macd['EMA_26'] = ema_26_period
    macd = ema_12_period - ema_26_period
    df_macd['MACD_SIGNAL'] = ewma(macd, span=9).mean()
    df_macd['MACD'] = macd

    return macd, df_macd


def compute_commodity_channel_index(prices_all, lookback):
    """
    function to compute the momentum
    """
    # Indicator -5
    # Formula to calculate CCI
    # Source: https://www.investopedia.com/terms/c/commoditychannelindex.asp
    # CCI= Typical Price−MA/.015×Mean Deviation

    prices_all = prices_all.divide(prices_all.iloc[0])
    df_commodity_channel_index = prices_all
    sma = prices_all.rolling(lookback).mean()
    std = prices_all.rolling(lookback).std()
    commodity_channel_index = (prices_all - sma) / (.015 * std)
    df_commodity_channel_index['CCI'] = commodity_channel_index

    return commodity_channel_index, df_commodity_channel_index


def plot_computed_bb(df_bb):
    df_bb[['JPM', 'SMA', 'TOP_BAND', 'BOTTOM_BAND', 'BB']].plot(figsize=(10, 4))
    plt.title('JPM' + ' Bollinger Bands')
    plt.axis('tight')
    plt.ylabel('Prices(normalized)')
    plt.grid()
    plt.savefig('Bollinger Bands.png')


def plot_computed_sma(df_prices_for_sma_calc):
    df_prices_for_sma_calc[['NORM_PRICES', 'SMA_NORM', 'NORM_PRICES_BY_SMA']].plot(figsize=(10, 4))
    plt.title('JPM' + ' SMA')
    plt.axis('tight')
    plt.ylabel('Prices(normalized)')
    plt.grid()
    plt.savefig('SMA.png')


def plot_computed_standard_deviation(df_prices_for_sma_calc):
    df_prices_for_sma_calc[['STD', 'Prices(normalized)']].plot(figsize=(10, 4))
    plt.title('JPM' + ' Standard Deviation')
    plt.axis('tight')
    plt.ylabel('Prices(normalized)')
    plt.grid()
    plt.savefig('STD.png')


def plot_computed_commodity_channel_index(df_commodity_channel_index):
    df_commodity_channel_index[['CCI']].plot(figsize=(10, 4))
    plt.title('JPM' + ' Commodity Channel Index (CCI)')
    plt.axis('tight')
    plt.ylabel('Prices(normalized)')
    plt.grid()
    plt.savefig('CCI.png')


def plot_computed_df_macd(df_macd):
    df_macd[['MACD', 'EMA_12', 'EMA_26', 'Prices']].plot(figsize=(10, 4))
    plt.title('JPM' + ' Moving Average Convergence Divergence (MACD)')
    plt.axis('tight')
    plt.ylabel('Prices(normalized)')
    plt.grid()
    plt.savefig('MACD.png')


def test_code():
    """
    Helper function to test code
    """
    # this is a helper function you can use to test your code
    # note that during autograding his function will not be called.
    # Define input parameters

    start_date = dt.datetime(2008, 1, 1)
    end_date = dt.datetime(2009, 12, 31)
    symbols = ['JPM']
    lookback = 20

    dates = pd.date_range(start_date, end_date)
    prices_all = get_data(symbols, dates, True, 'Adj Close')
    prices_all = prices_all[symbols]

    # . Indicator source
    # sources https://www.visualcapitalist.com/12-types-technical-indicators-stocks/
    # https://www.ig.com/us/trading-strategies/10-trading-indicators-every-trader-should-know-190604

    # 1. compute volatility using indicator - Standard Deviation
    # Used to measure expected risk and to determine the significance of certain price movements.
    standard_deviation, df_prices_for_sd = compute_standard_deviation(prices_all, lookback)
    plot_computed_standard_deviation(df_prices_for_sd)

    # 2. Trend indicators - compute sma
    sma_normalized, df_prices_for_sma_calc = compute_sma(prices_all, lookback)
    plot_computed_sma(df_prices_for_sma_calc)
    print(sma_normalized)

    # 3. compute BB
    top_band, bottom_band, bollinger_band, df_bb = compute_bollinger_band(prices_all, lookback)
    plot_computed_bb(df_bb)
    print(top_band)
    print(bottom_band)
    print(bollinger_band)

    # 4. Trend indicators - compute Moving Average Convergence Divergence (MACD)
    macd, df_macd = compute_macd(prices_all)
    plot_computed_df_macd(df_macd)
    print(top_band)
    print(bottom_band)
    print(bollinger_band)

    # 5.  - Commodity Channel Index (CCI)
    # commodity_channel_index= compute_commodity_channel_index(prices_all, lookback)
    commodity_channel_index, df_commodity_channel_index = compute_commodity_channel_index(prices_all, lookback)
    plot_computed_commodity_channel_index(df_commodity_channel_index)
    print(top_band)
    print(bottom_band)
    print(bollinger_band)


if __name__ == "__main__":
    test_code()
