""""""
""" Has implementation, has all experiment
Student Name: Ravindra Singh  		  	   		     		  		  		    	 		 		   		 		  

"""
from datetime import datetime

import yfinance as yf
from more_itertools import tabulate
from pandas_datareader import data as pdr
from sklearn.preprocessing import MinMaxScaler
## keras is a neural network library
from keras.layers import LSTM
from keras.layers import Dense
from keras.models import Sequential
import seaborn as sns
# For reading stock data from yahoo
from pandas_datareader.data import DataReader

yf.pdr_override()
import numpy as np
from scipy.stats import norm
import matplotlib.pyplot as plt
from tabulate import tabulate
import pandas_datareader as web
import pandas as pd


def get_data_from_yahoo_finance(start_date, end_date, ticker):
    print('ticker_list', ticker)

    data_frame = pdr.get_data_yahoo(ticker, start=start_date, end=end_date)

    for stock in ticker:
        globals()[stock] = DataReader(stock, 'yahoo', start_date, end_date)

    company_list = [AAPL, IBM] # this is not compile error, this is global variable
    company_name = ['APPLE', 'IBM']

    for company, com_name in zip(company_list, company_name):
        company['company_name'] = com_name

    df = pd.concat(company_list, axis=0)
    df.tail(10)

    # Summary Stats
    AAPL.describe()

    # General info
    AAPL.info()

    # Let's see a historical view of the closing price
    plt.clf()
    plt.close()
    plt.figure(figsize=(12, 8))
    plt.subplots_adjust(top=1.25, bottom=1.2)

    for i, company in enumerate(company_list, 1):
        plt.subplot(2, 2, i)
        company['Adj Close'].plot()
        plt.ylabel('Adj Close')
        plt.xlabel(None)
        plt.title(f"{ticker[i - 1]}")
        plt.savefig('./charts/' + ticker[i - 1] + '.png')

    # Now let's plot the total volume of stock being traded each day
    plt.clf()
    plt.close()
    plt.figure(figsize=(12, 8))
    plt.subplots_adjust(top=1.25, bottom=1.2)

    for i, company in enumerate(company_list, 1):
        plt.subplot(2, 2, i)
        company['Volume'].plot()
        plt.ylabel('Volume')
        plt.xlabel(None)
        plt.title(f"{ticker[i - 1]}")
        plt.savefig('./charts/' + ticker[i - 1] + '.png')

    #2. What was the moving average of the various stocks?
    ma_day = [10, 20, 50]

    for ma in ma_day:
        for company in company_list:
            column_name = f"MA for {ma} days"
            company[column_name] = company['Adj Close'].rolling(ma).mean()

    print(AAPL.columns)

    #Now let's go ahead and plot all the additional Moving Averages
    df.groupby("company_name").hist(figsize=(12, 12));

    fig, axes = plt.subplots(nrows=2, ncols=2)
    fig.set_figheight(8)
    fig.set_figwidth(15)

    AAPL[['Adj Close', 'MA for 10 days', 'MA for 20 days', 'MA for 50 days']].plot(ax=axes[0, 0])
    axes[0, 0].set_title('APPLE')

    IBM[['Adj Close', 'MA for 10 days', 'MA for 20 days', 'MA for 50 days']].plot(ax=axes[0, 1])
    axes[0, 1].set_title('IBM')
    fig.tight_layout()


    #3. What was the daily return of the stock on average?
    # We'll use pct_change to find the percent change for each day
    for company in company_list:
        company['Daily Return'] = company['Adj Close'].pct_change()

    # Then we'll plot the daily return percentage
    fig, axes = plt.subplots(nrows=2, ncols=2)
    fig.set_figheight(8)
    fig.set_figwidth(15)

    AAPL['Daily Return'].plot(ax=axes[0, 0], legend=True, linestyle='--', marker='o')
    axes[0, 0].set_title('APPLE')

    IBM['Daily Return'].plot(ax=axes[0, 1], legend=True, linestyle='--', marker='o')
    axes[0, 1].set_title('IBM')
    fig.tight_layout()

    # Note the use of dropna() here, otherwise the NaN values can't be read by seaborn
    plt.figure(figsize=(12, 12))

    for i, company in enumerate(company_list, 1):
        plt.subplot(2, 2, i)
        sns.distplot(company['Daily Return'].dropna(), bins=100, color='purple')
        plt.ylabel('Daily Return')
        plt.title(f'{company_name[i - 1]}')
        plt.savefig('./charts/' + ticker[i - 1] + '.png')
    # Could have also done:
    # AAPL['Daily Return'].hist()

    #4. What was the correlation between different stocks closing prices?
    # Grab all the closing prices for the tech stock list into one DataFrame
    closing_df = DataReader(ticker, 'yahoo', start_date, end_date)['Adj Close']

    # Let's take a quick look
    closing_df.head()
    # Make a new tech returns DataFrame
    tech_rets = closing_df.pct_change()
    tech_rets.head()

    # Comparing AAPL to itself should show a perfectly linear relationship
    sns.jointplot('AAPL', 'AAPL', tech_rets, kind='scatter', color='seagreen')
    plt.show()

    # We'll use joinplot to compare the daily returns of AAPL and IBM
    sns.jointplot('AAPL', 'IBM', tech_rets, kind='scatter')
    plt.show()

    # We can simply call pairplot on our DataFrame for an automatic visual analysis
    # of all the comparisons

    sns.pairplot(tech_rets, kind='reg')

    # Set up our figure by naming it returns_fig, call PairPLot on the DataFrame
    return_fig = sns.PairGrid(tech_rets.dropna())

    # Using map_upper we can specify what the upper triangle will look like.
    return_fig.map_upper(plt.scatter, color='purple')

    # We can also define the lower triangle in the figure, including the plot type (kde)
    # or the color map (BluePurple)
    return_fig.map_lower(sns.kdeplot, cmap='cool_d')

    # Finally we'll define the diagonal as a series of histogram plots of the daily return
    return_fig.map_diag(plt.hist, bins=30)

    # Set up our figure by naming it returns_fig, call PairPLot on the DataFrame
    returns_fig = sns.PairGrid(closing_df)

    # Using map_upper we can specify what the upper triangle will look like.
    returns_fig.map_upper(plt.scatter, color='purple')

    # We can also define the lower triangle in the figure, inclufing the plot type (kde) or the color map (BluePurple)
    returns_fig.map_lower(sns.kdeplot, cmap='cool_d')

    # Finally we'll define the diagonal as a series of histogram plots of the daily return
    returns_fig.map_diag(plt.hist, bins=30)

    # Let's go ahead and use sebron for a quick correlation plot for the daily returns
    sns.heatmap(tech_rets.corr(), annot=True, cmap='summer')

    sns.heatmap(closing_df.corr(), annot=True, cmap='summer')

    #5. How much value do we put at risk by investing in a particular stock

    # Let's start by defining a new DataFrame as a clenaed version of the oriignal tech_rets DataFrame
    rets = tech_rets.dropna()

    area = np.pi * 20
    plt.clf()
    plt.close()
    plt.figure(figsize=(12, 10))
    plt.scatter(rets.mean(), rets.std(), s=area)
    plt.xlabel('Expected return')
    plt.ylabel('Risk')

    for label, x, y in zip(rets.columns, rets.mean(), rets.std()):
        plt.annotate(label, xy=(x, y), xytext=(50, 50), textcoords='offset points', ha='right', va='bottom',
                     arrowprops=dict(arrowstyle='-', color='blue', connectionstyle='arc3,rad=-0.3'))

    #6. Predicting the closing price stock price of APPLE inc:
    # Get the stock quote
    df = DataReader('AAPL', data_source='yahoo', start='2012-01-01', end=datetime.now())
    # Show teh data
    df
    plt.clf()
    plt.close()
    plt.figure(figsize=(16, 8))
    plt.title('Close Price History')
    plt.plot(df['Close'])
    plt.xlabel('Date', fontsize=18)
    plt.ylabel('Close Price USD ($)', fontsize=18)
    plt.show()

    # Create a new dataframe with only the 'Close column
    data = df.filter(['Close'])
    # Convert the dataframe to a numpy array
    dataset = data.values
    # Get the number of rows to train the model on
    training_data_len = int(np.ceil(len(dataset) * .95))

    training_data_len

    # Scale the data
    from sklearn.preprocessing import MinMaxScaler

    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled_data = scaler.fit_transform(dataset)

    scaled_data

    # Create the training data set
    # Create the scaled training data set
    train_data = scaled_data[0:int(training_data_len), :]
    # Split the data into x_train and y_train data sets
    x_train = []
    y_train = []
    plt.clf()
    plt.close()
    for i in range(60, len(train_data)):
        x_train.append(train_data[i - 60:i, 0])
        y_train.append(train_data[i, 0])
        if i <= 61:
            print(x_train)
            print(y_train)
            print()

    # Convert the x_train and y_train to numpy arrays
    x_train, y_train = np.array(x_train), np.array(y_train)

    # Reshape the data
    x_train = np.reshape(x_train, (x_train.shape[0], x_train.shape[1], 1))
    # x_train.shape

    # Build the LSTM model
    model = Sequential()
    model.add(LSTM(128, return_sequences=True, input_shape=(x_train.shape[1], 1)))
    model.add(LSTM(64, return_sequences=False))
    model.add(Dense(25))
    model.add(Dense(1))

    # Compile the model
    model.compile(optimizer='adam', loss='mean_squared_error')

    # Train the model
    model.fit(x_train, y_train, batch_size=1, epochs=1)

    # Create the testing data set
    # Create a new array containing scaled values from index 1543 to 2002
    test_data = scaled_data[training_data_len - 60:, :]
    # Create the data sets x_test and y_test
    x_test = []
    y_test = dataset[training_data_len:, :]
    for i in range(60, len(test_data)):
        x_test.append(test_data[i - 60:i, 0])

    # Convert the data to a numpy array
    x_test = np.array(x_test)

    # Reshape the data
    x_test = np.reshape(x_test, (x_test.shape[0], x_test.shape[1], 1))

    # Get the models predicted price values
    predictions = model.predict(x_test)
    predictions = scaler.inverse_transform(predictions)

    # Get the root mean squared error (RMSE)
    rmse = np.sqrt(np.mean(((predictions - y_test) ** 2)))
    print ('rmse LSTM',rmse)
    plt.clf()
    plt.close()
    # Plot the data
    train = data[:training_data_len]
    valid = data[training_data_len:]
    valid['Predictions'] = predictions
    # Visualize the data
    plt.figure(figsize=(16, 8))
    plt.title('Model')
    plt.xlabel('Date', fontsize=18)
    plt.ylabel('Close Price USD ($)', fontsize=18)
    plt.plot(train['Close'])
    plt.plot(valid[['Close', 'Predictions']])
    plt.legend(['Train', 'Val', 'Predictions'], loc='lower right')
    plt.savefig('./charts/LSTM_Predictions.png')

    # Show the valid and predicted prices
    print('valid', valid)

    # get closing prices
    data_frame_closing_prices = pdr.get_data_yahoo(ticker, start=start_date, end=end_date)['Close']
    data_frame_closing_prices.to_csv('./data/Tickers.csv')
    return data_frame_closing_prices


def calculate_risk_using_variance_covariance(df_closing_prices, start_val, tickers):
    # set investment weights, we want more AAPL and Less IBM
    weights = np.array([.60, .40])

    # calculate periodic returns
    periodic_return = df_closing_prices.pct_change()

    print('periodic_return', periodic_return.tail())

    # create var-covar matrix
    var_covar_matrix = periodic_return.cov()
    print(var_covar_matrix)

    # calculate mean return for each stock
    average_return = periodic_return.mean()

    print('average_return', average_return)

    # normalize individual means against investment weights
    portfolio_mean = average_return.dot(weights)

    # Calculate portfolio standard deviation - estimate the standard deviation using weights
    portfolio_standard_deviation = np.sqrt(weights.T.dot(var_covar_matrix).dot(weights))

    # Calculate mean of investment
    # mu = mean
    mu_mean_investment = (1 + portfolio_mean) * start_val

    # Calculate standard deviation of investmnet
    std_standard_deviation_investment = start_val * portfolio_standard_deviation

    # Select our confidence interval, we choose 95% confidence here
    # alpha = confidence  level
    alpha_confidence_levels = [0.10, 0.05, 0.01]

    portfolio_value = df_closing_prices[tickers[0]].sum() + df_closing_prices[tickers[1]].sum()
    calculated_vars = []
    calculated_cvars = []

    for confidence in alpha_confidence_levels:
        # calculate var
        calculated_var = calc_VaR(confidence, portfolio_mean, portfolio_standard_deviation, portfolio_value)
        calculated_vars.append(calculated_var)

        # calculate cvar
        calculated_cvar = calc_CVaR(confidence, portfolio_mean, portfolio_standard_deviation, portfolio_value)
        calculated_cvars.append(calculated_cvar)

    tabulateData(calculated_vars, alpha_confidence_levels, 'VaR 1-day')
    print('\n')
    tabulateData(calculated_cvars, alpha_confidence_levels, 'CVaR 1-day')
    print('\n')

    # print('====================Calculated VaRs==================================')
    # tabulateData(calculated_vars, alpha_confidence_levels, 'VaR 1-day')
    # print('====================Calculated CVaR=================================')
    # tabulateData(calculated_cvars, alpha_confidence_levels, 'CVaR 1-day')
    # print('=====================================================================')

    num_days = 30
    # VaR at n_days
    VaRs_array = [
        [np.round(calc_VaR_n_day(conf_level, portfolio_mean, portfolio_standard_deviation, portfolio_value, i), 2) for i
         in
         range(1, num_days + 1)] for conf_level in alpha_confidence_levels]
    VaR_n_day = [vals[-1] for vals in VaRs_array]

    tabulateData(VaR_n_day, alpha_confidence_levels, title='VaR at 30 days')
    print('\n')
    plot_n_day_var(VaRs_array, 'VaR', num_days, alpha_confidence_levels)

    # CVaR at n_days
    CVaRs_array = [
        [np.round(calc_CVaR_n_day(conf_level, portfolio_mean, portfolio_standard_deviation, portfolio_value, i), 2) for
         i in
         range(1, num_days + 1)] for conf_level in alpha_confidence_levels]
    CVaR_n_day = [vals[-1] for vals in CVaRs_array]
    tabulateData(CVaR_n_day, alpha_confidence_levels, title='VaR at 30 days')
    print('\n')
    plot_n_day_var(CVaRs_array, 'CVaR', num_days, alpha_confidence_levels)

    # 4. Calculate the inverse of the normal cumulative distribution (PPF) with a specified confidence interval, standard deviation, and mean
    # Using SciPy ppf method to generate values for the
    # inverse cumulative distribution function to a normal distribution
    # Plugging in the mean, standard deviation of our portfolio
    # as calculated above
    # https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.norm.html
    # cutoff1 = norm.ppf(alpha_confidence_level_1, mu_mean_investment, std_standard_deviation_investment)

    # 5. Estimate the value at risk (VaR) for the portfolio by subtracting the initial investment from the calculation in step 4
    # Finally, we can calculate the VaR at our confidence interval
    # var_1d1 = start_val - cutoff1
    # print('We are saying with 95% confidence that our portfolio of 1M USD will not exceed losses greater than ' + str(var_1d1) + ' USD over a one day period.')


# calculate our VaR using the following code
def calc_VaR(alpha, mu, std, portfolio_value):
    return abs((mu - norm.ppf(alpha) * std) * portfolio_value)


# calculate our CVaR using the following code
def calc_CVaR(alpha, mu, std, portfolio_value):
    return (mu + alpha ** -1 * norm.pdf(norm.ppf(alpha)) * std) * portfolio_value


# Parametric VaR at nth day
def calc_VaR_n_day(alpha, mu, std, portfolio_value, num_days):
    '''
    alpha = confidence level
    mu = mean
    std = portfolio change standard deviation
    portfolio = portfolio value
    num_days = nth day
    '''
    return abs((mu - norm.ppf(alpha) * std * np.sqrt(num_days)) * portfolio_value)


# Parametric CVaR at nth day
def calc_CVaR_n_day(alpha, mu, std, portfolio_value, num_days):
    return (mu + alpha ** -1 * norm.pdf(norm.ppf(alpha)) * std * np.sqrt(num_days)) * portfolio_value


def tabulateData(values, conf_levels, title='VaR'):
    table = [[('{0}%'.format((1 - conf_levels[i]) * 100)), values[i]] for i in range(len(conf_levels))]
    print(tabulate(table, headers=["Confidence Level", title]))


# VaR over n-day period
# Multiply 1-day var by square root of time peiord
# assuming stddev in stock returns increase by square root of time
def plot_n_day_var(VaRs_array, title, num_days, conf_levels):
    plt.clf()
    plt.close()
    for idx, VaRs_nday in enumerate(VaRs_array):
        plt.plot(range(1, num_days + 1), VaRs_nday, label='{}%'.format((1 - conf_levels[idx]) * 100))
    plt.xlabel('No. of days')
    plt.ylabel('{0}'.format(title))
    plt.title('{0} over {0} day period'.format(title, num_days))
    plt.legend()
    plt.savefig('./charts/' + title + '.png')
    # plt.show()


def createHistoricalSimulation(returns, start_vals):
    return start_vals.dot(returns)


def calculate_risk_using_hist_sim(df_changes, start_vals, alpha_confidence_levels):
    histSimulation = np.array(
        [createHistoricalSimulation(np.array(df_changes.iloc[i, :]), start_vals) for i in range(df_changes.shape[0])])

    # histVaRs
    histVaRs = [abs(np.percentile(histSimulation, conf_level * 100)) for conf_level in alpha_confidence_levels]
    tabulateData(histVaRs, alpha_confidence_levels, title='Historical VaR')
    print('\n')

    # CVaRs
    histCVaRs = [abs(np.mean(histSimulation[histSimulation < np.percentile(histSimulation, conf_level * 100)])) for
                 conf_level in alpha_confidence_levels]
    tabulateData(histCVaRs, alpha_confidence_levels, title='Historical CVaR')

    # Plot
    plot_hist_sim(histSimulation)


def plot_hist_sim(histSimulation):
    plt.figure(figsize=(10, 8))
    plt.plot(histSimulation)
    plt.ylabel('P/L in portolio value')
    plt.xlabel('Simulation count')
    plt.title('P/L using historical simulation')
    # plt.show()
    plt.savefig('./charts/P-L using historical simulation.png')

    plt.clf()
    plt.close()

    print('\n')

    plt.figure(figsize=(10, 8))
    plt.hist(histSimulation, density=True, bins=30)
    plt.xlabel('P/L in portolio value')
    plt.ylabel('Density')
    plt.title('Histogram of P/L using historical simulation')
    plt.savefig('./charts/Histogram of P-L using historical simulation.png')
    # plt.show()


def calculate_risk_using_monte_carlo_simulation(df_simulation, num_days, num_simulations, portfolio_value,
                                                starting_point, var_covar_matrix, alpha_confidence_levels):
    for i in range(num_simulations):

        sim_usd_values = starting_point.to_numpy()
        sim_portfolio = [sum(sim_usd_values)]

        for j in range(num_days):
            # Using a normal multivariate distribution with a covariate matrix to get returns for each FX.
            sim_returns = np.random.multivariate_normal([0, 0], var_covar_matrix)
            sim_usd_values = (1 + sim_returns) * sim_usd_values
            sim_portfolio.append(sum(sim_usd_values))

        df_simulation[i] = sim_portfolio

        plot_monte_carlo_simulation(df_simulation)

    # sim_VaRs
    sim_VaRs = [abs(portfolio_value - np.percentile(df_simulation.iloc[1], conf_level * 100)) for conf_level in
                alpha_confidence_levels]
    tabulateData(sim_VaRs, alpha_confidence_levels, title='Simulated VaR')
    print('\n\n')

    # CVaRs
    sim_CVaRs = [abs(portfolio_value - np.mean(
        df_simulation.iloc[1][df_simulation.iloc[1] < np.percentile(df_simulation.iloc[1], conf_level * 100)])) for
                 conf_level in alpha_confidence_levels]
    tabulateData(sim_CVaRs, alpha_confidence_levels, title='Simulated CVaR')

    # sim_VaRs
    sim_VaRs_30 = [abs(portfolio_value - np.percentile(df_simulation.iloc[num_days], conf_level * 100)) for
                   conf_level in alpha_confidence_levels]
    tabulateData(sim_VaRs_30, alpha_confidence_levels, title='Simulated VaR')
    print('\n\n')

    # CVaRs
    sim_CVaRs_30 = [abs(portfolio_value - np.mean(df_simulation.iloc[num_days][
                                                      df_simulation.iloc[num_days] < np.percentile(
                                                          df_simulation.iloc[num_days], conf_level * 100)])) for
                    conf_level in alpha_confidence_levels]
    tabulateData(sim_CVaRs_30, alpha_confidence_levels, title='Simulated CVaR')


def plot_monte_carlo_simulation(df_simulation):
    # Plotting the simulated value of our portfolio.
    plt.clf()
    plt.close()
    plt.figure(figsize=(10, 5))
    plt.plot(df_simulation)
    plt.xlabel('Days out')
    plt.ylabel('Portfolio Value')
    plt.title(r'Simulated Portfolio Value', fontsize=14, fontweight='bold')
    plt.savefig('./charts/Monte-Carlo-Simulated Portfolio Value.png')


def calculate_risk_using_lstm(df_prices, df_closing_prices):
    ## Create a seperate dataframe with only colse column
    stock_close_data = df_prices.filter(['Close'])

    ## Convert created dataframe into numpy array
    stock_close_dataset = stock_close_data.values

    ## Split dataset for training and testing
    trainingDataLength = np.math.ceil(len(stock_close_dataset) * 0.8)

    ## Display the training data length
    trainingDataLength
    ## Scaling the data its come under preprocessing stage
    ## Create feature range into 0,1
    scaler = MinMaxScaler(feature_range=(0, 1))

    ## Transform the data into
    scaledData = scaler.fit_transform(stock_close_dataset)

    ## Display scaled data value
    scaledData

    ## Create a new dataset which contain scaled value
    StockTrainData = scaledData[0:trainingDataLength, :]

    ## Spliting the dataset into two parts such as Xtrain and Ytrain datasets
    Xtrain = []
    Ytrain = []

    for i in range(60, len(StockTrainData)):
        Xtrain.append(StockTrainData[i - 60:i, 0])
        Ytrain.append(StockTrainData[i, 0])
        if i <= 61:
            print(Xtrain)
            print(Ytrain)
            print()

    ## Convert Xtrain data, Ytrain data into numpy array
    Xtrain = np.array(Xtrain)
    Ytrain = np.array(Ytrain)

    ## Reshape the Xtrain data (number of column and number of row)
    Xtrain = np.reshape(Xtrain, (Xtrain.shape[0], Xtrain.shape[1], 1))
    Xtrain.shape

    ## Develop LSTM model
    model = Sequential()

    ## Assign neurons as 50
    neurons = 50

    ## First LSTM layer
    model.add(LSTM(neurons, return_sequences=True, input_shape=(Xtrain.shape[1], 1)))

    ## Second LSTM layer, no more layer for lstm so return_sequence is false
    model.add(LSTM(neurons, return_sequences=False))

    ## Adding Dense layer which always have 25 neurons by default
    model.add(Dense(25))
    model.add(Dense(1))

    ##Compile  model
    ## mse= mean squared error
    model.compile(optimizer='adam', loss='mse')

    ## Fiting model with given training dataset
    history_data = model.fit(Xtrain, Ytrain, batch_size=50, epochs=200, verbose=2, validation_split=0.2)

    ## Visualize train and validation loss
    plt.figure(figsize=(20, 10))
    plt.title('Training validation loss')
    plt.plot(history_data.history['loss'])
    plt.plot(history_data.history['val_loss'])
    plt.ylabel('Training loss')
    plt.xlabel('epochs')
    plt.legend(['train', 'validation'], loc='upper left')
    plt.show()

    ##Create testing dataset, new array which contains scaled value from 2275 out of 2843
    testingData = scaledData[trainingDataLength - 60:, :]

    ## Create dataset Xtest and Ytest
    Xtest = []
    Ytest = stock_close_dataset[trainingDataLength:, :]
    for i in range(60, len(testingData)):
        Xtest.append(testingData[i - 60:i, 0])

    ## Convert data into numpy array
    Xtest = np.array(Xtest)
    Xtest

    ## Reshape data from 2 Dimensional to 3 Dimensional
    Xtest = np.reshape(Xtest, (Xtest.shape[0], Xtest.shape[1], 1))

    ## Get predicted stock price value
    ## Unscaling the predicted value
    predictions = model.predict(Xtest)
    predictions = scaler.inverse_transform(predictions)
    predictions

    ## Get RSME(Root Mean Squared Error) it nearl to 5, then it will be best model
    rmse = np.sqrt(np.mean(((predictions - Ytest) ** 2)))
    rmse

    ## Ploting data to graph train and validation
    training = stock_close_data[:trainingDataLength]
    validation = stock_close_data[trainingDataLength:]
    validation['Predictions'] = predictions

    ## Visualize trainning, validating and predicting values in graph
    plt.figure(figsize=(20, 10))
    plt.title('Trained Model')
    plt.xticks(range(0, df_prices.shape[0], 500), df_prices['Date'].loc[::500], rotation=45)
    plt.xlabel('Date', fontsize=20)
    plt.ylabel('Close Stock Price $ (USD)', fontsize=20)
    plt.plot(training['Close'])
    plt.plot(validation[['Close', 'Predictions']])
    plt.legend(['Training', 'Validation', 'Predictions'], loc='lower right')
    plt.show()

    ## Show  validate and predicted stock prices
    validation